export type OrbState = "listening" | "reasoning" | "searching" | "done";

export const ORB_STATES: OrbState[];
export const ORB_COLORS: string[];

export interface OrbOptions {
  /** Particle count. Default 16000. 8000 is plenty on low-end phones. */
  particles?: number;
  /** Four hex colors, one per state. */
  colors?: string[];
  /** Orb size relative to the canvas' shortest side. Default 0.8. */
  scale?: number;
  /** Particle size relative to the orb radius. Default 0.011. */
  pointSize?: number;
  /** Soft glow pass strength, 0 turns it off. Default 0.018. */
  glow?: number;
  /** Global time multiplier. Default 1. */
  speed?: number;
  /** Morph duration in seconds. Default 1.15. */
  transition?: number;
  /** Device pixel ratio cap. Default 2. */
  maxDpr?: number;
  /** Random seed: same seed, same orb. */
  seed?: number;
  /** Start animating right away. Default true. */
  autoplay?: boolean;
  /** Keep the drawing buffer (needed for canvas.toDataURL / video export). */
  preserveDrawingBuffer?: boolean;
  onStateChange?: (state: OrbState, index: number) => void;
}

export interface AIStatusOrb {
  setState(state: OrbState | number, opts?: { instant?: boolean }): AIStatusOrb;
  getState(): OrbState;
  /** Current accent color [r, g, b] 0-255, blended during transitions. */
  getColor(): [number, number, number];
  /** 0..1 mic level for the listening state; null goes back to the idle wobble. */
  setVoiceLevel(level: number | null): AIStatusOrb;
  setColors(hexes: string[]): AIStatusOrb;
  /** Render one frame at an exact time in seconds. */
  renderAt(seconds: number): AIStatusOrb;
  play(): AIStatusOrb;
  pause(): AIStatusOrb;
  resize(): AIStatusOrb;
  readonly time: number;
  destroy(): void;
}

export function createAIStatusOrb(canvas: HTMLCanvasElement, options?: OrbOptions): AIStatusOrb;
