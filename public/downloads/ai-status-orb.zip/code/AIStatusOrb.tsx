"use client";
/**
 * AI Status Orb — React / Next.js wrapper
 * Put ai-status-orb.js (+ ai-status-orb.d.ts) next to this file.
 *
 *   <AIStatusOrb state={isStreaming ? "reasoning" : "done"} className="h-80 w-80" />
 *
 * Vedang Paatil — vedangpaatil.com/library
 */
import { useEffect, useRef } from "react";
import { createAIStatusOrb, type OrbState, type OrbOptions, type AIStatusOrb as Orb } from "./ai-status-orb.js";

type Props = {
  state: OrbState;
  /** 0..1 live mic level for the listening state. Leave undefined for the idle wobble. */
  voiceLevel?: number;
  options?: Omit<OrbOptions, "onStateChange">;
  className?: string;
  style?: React.CSSProperties;
  label?: string;
};

export default function AIStatusOrb({ state, voiceLevel, options, className, style, label }: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const orbRef = useRef<Orb | null>(null);

  // create once (re-create only if the canvas remounts)
  useEffect(() => {
    if (!canvasRef.current) return;
    let orb: Orb;
    try {
      orb = createAIStatusOrb(canvasRef.current, options);
    } catch {
      return; // no WebGL: render nothing rather than crash the page
    }
    orb.setState(state, { instant: true });
    orbRef.current = orb;
    return () => { orb.destroy(); orbRef.current = null; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => { orbRef.current?.setState(state); }, [state]);
  useEffect(() => { orbRef.current?.setVoiceLevel(voiceLevel ?? null); }, [voiceLevel]);

  return (
    <canvas
      ref={canvasRef}
      role="img"
      aria-label={label ?? `AI is ${state}`}
      className={className}
      style={{ display: "block", width: "100%", height: "100%", ...style }}
    />
  );
}
