/**
 * AI Status Orb
 * A particle orb that shows what your AI is doing: listening, reasoning, searching, done.
 * One WebGL draw call, no dependencies.
 *
 *   import { createAIStatusOrb } from "./ai-status-orb.js";
 *   const orb = createAIStatusOrb(document.querySelector("canvas"));
 *   orb.setState("reasoning");
 *
 * Vedang Paatil — vedangpaatil.com/library
 */

export const ORB_STATES = ["listening", "reasoning", "searching", "done"];
export const ORB_COLORS = ["#ff8fa3", "#7c9cff", "#ffbf5e", "#6ee7b0"];

const TAU = Math.PI * 2;
const hexToRgb = (h) => [1, 3, 5].map((k) => parseInt(h.slice(k, k + 2), 16) / 255);
const clamp = (k) => Math.min(1, Math.max(0, k));
const lerp = (a, b, k) => a + (b - a) * k;
const ease = (k) => (k < 0.5 ? 4 * k * k * k : 1 - Math.pow(-2 * k + 2, 3) / 2);

const VERT = `
attribute vec3 aPos; attribute vec3 aCol;
uniform vec2 uRes; uniform vec2 uC; uniform float uR; uniform float uPt; uniform float uGain;
varying vec3 vCol;
void main(){
  float f = 3.4; float s = f / (f - aPos.z);
  vec2 p = uC + vec2(aPos.x, -aPos.y) * uR * s;
  vec2 c = p / uRes * 2.0 - 1.0; c.y = -c.y;
  gl_Position = vec4(c, 0.0, 1.0);
  gl_PointSize = uPt * s;
  vCol = aCol * (0.5 + 0.5 * s) * uGain;
}`;
const FRAG = `
precision mediump float;
varying vec3 vCol;
void main(){
  float r = length(gl_PointCoord - 0.5);
  float a = smoothstep(0.5, 0.08, r);
  vec3 c = vCol * a;
  gl_FragColor = vec4(c, max(c.r, max(c.g, c.b)));
}`;

/**
 * @param {HTMLCanvasElement} canvas
 * @param {object} [options]
 * @param {number} [options.particles=16000]   particle count (8k is plenty on low-end phones)
 * @param {string[]} [options.colors]          4 hex colors, one per state
 * @param {number} [options.scale=0.8]         orb size relative to the canvas' shortest side
 * @param {number} [options.pointSize=0.011]   particle size relative to the orb radius
 * @param {number} [options.glow=0.018]        soft glow pass strength (0 = off)
 * @param {number} [options.speed=1]           global time multiplier
 * @param {number} [options.transition=1.15]   morph duration in seconds
 * @param {number} [options.maxDpr=2]          device pixel ratio cap
 * @param {number} [options.seed=20260926]     random seed (same seed = same orb)
 * @param {boolean} [options.autoplay=true]    start the animation loop immediately
 * @param {(state:string, index:number)=>void} [options.onStateChange]
 */
export function createAIStatusOrb(canvas, options = {}) {
  const o = {
    particles: 16000, colors: ORB_COLORS, scale: 0.8, pointSize: 0.011, glow: 0.018,
    speed: 1, transition: 1.15, maxDpr: 2, seed: 20260926, autoplay: true,
    preserveDrawingBuffer: false, onStateChange: null, ...options,
  };
  const reduced = typeof matchMedia === "function" && matchMedia("(prefers-reduced-motion: reduce)").matches;
  if (reduced) { o.speed *= 0.35; o.transition *= 0.6; }

  const gl = canvas.getContext("webgl", {
    antialias: false, alpha: true, premultipliedAlpha: true, preserveDrawingBuffer: o.preserveDrawingBuffer,
  });
  if (!gl) throw new Error("AIStatusOrb: WebGL is not available in this browser.");

  // ---- GL setup
  const compile = (type, src) => {
    const s = gl.createShader(type); gl.shaderSource(s, src); gl.compileShader(s);
    if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(s));
    return s;
  };
  const prog = gl.createProgram();
  gl.attachShader(prog, compile(gl.VERTEX_SHADER, VERT));
  gl.attachShader(prog, compile(gl.FRAGMENT_SHADER, FRAG));
  gl.linkProgram(prog); gl.useProgram(prog);
  const bPos = gl.createBuffer(), bCol = gl.createBuffer();
  const aPos = gl.getAttribLocation(prog, "aPos"), aCol = gl.getAttribLocation(prog, "aCol");
  gl.bindBuffer(gl.ARRAY_BUFFER, bPos); gl.enableVertexAttribArray(aPos); gl.vertexAttribPointer(aPos, 3, gl.FLOAT, false, 0, 0);
  gl.bindBuffer(gl.ARRAY_BUFFER, bCol); gl.enableVertexAttribArray(aCol); gl.vertexAttribPointer(aCol, 3, gl.FLOAT, false, 0, 0);
  const U = {};
  for (const n of ["uRes", "uC", "uR", "uPt", "uGain"]) U[n] = gl.getUniformLocation(prog, n);
  gl.enable(gl.BLEND); gl.blendFunc(gl.ONE, gl.ONE); gl.clearColor(0, 0, 0, 0);

  // ---- particle seeds (deterministic)
  const N = o.particles;
  let seed = o.seed >>> 0;
  const rnd = () => ((seed = (seed * 1664525 + 1013904223) >>> 0) / 4294967296);
  const S = new Float32Array(N * 4); for (let i = 0; i < N * 4; i++) S[i] = rnd();
  const SPH = new Float32Array(N * 3); const GA = Math.PI * (3 - Math.sqrt(5));
  for (let i = 0; i < N; i++) {
    const y = 1 - ((i + 0.5) / N) * 2, r = Math.sqrt(1 - y * y), t = GA * i;
    SPH[i * 3] = Math.cos(t) * r; SPH[i * 3 + 1] = y; SPH[i * 3 + 2] = Math.sin(t) * r;
  }
  const PERM = new Uint32Array(N); for (let i = 0; i < N; i++) PERM[i] = i;
  for (let i = N - 1; i > 0; i--) { const j = (rnd() * (i + 1)) | 0; [PERM[i], PERM[j]] = [PERM[j], PERM[i]]; }
  const PERM2 = new Uint32Array(N); for (let i = 0; i < N; i++) PERM2[i] = PERM[(i * 7919) % N];

  const pos = new Float32Array(N * 3), col = new Float32Array(N * 3);
  const fromP = new Float32Array(N * 3), fromC = new Float32Array(N * 3);
  const tmp = [0, 0, 0, 0];
  let COLORS = o.colors.map(hexToRgb);

  // check mark polyline (done state)
  const CA = [-0.38, 0.02], CB = [-0.11, -0.26], CC = [0.42, 0.3];
  const L1 = Math.hypot(CB[0] - CA[0], CB[1] - CA[1]), L2 = Math.hypot(CC[0] - CB[0], CC[1] - CB[1]), LT = L1 + L2;

  const rot = (v, ay, ax) => {
    let x = v[0], y = v[1], z = v[2];
    let c = Math.cos(ay), s = Math.sin(ay); const nx = x * c + z * s; let nz = -x * s + z * c; x = nx; z = nz;
    c = Math.cos(ax); s = Math.sin(ax); const ny = y * c - z * s; nz = y * s + z * c;
    v[0] = x; v[1] = ny; v[2] = nz;
  };

  let voice = 0; // 0..1, drives the listening ripple
  let voiceOverride = null;

  function shape(st, i, t, v) {
    const s1 = S[i * 4], s2 = S[i * 4 + 1], s3 = S[i * 4 + 2], s4 = S[i * 4 + 3];
    if (st === 0) { // listening: dust sphere swelling with the voice
      const j = PERM[i] * 3, dx = SPH[j], dy = SPH[j + 1], dz = SPH[j + 2];
      const lat = Math.asin(dy), lon = Math.atan2(dz, dx);
      const rip = Math.sin(lat * 6 - t * 3.2) * (0.03 + 0.07 * voice) + Math.sin(lon * 4 + t * 1.2) * 0.015;
      const R = (0.8 + rip) * Math.pow(s3, 0.12);
      v[0] = dx * R; v[1] = dy * R; v[2] = dz * R; rot(v, t * 0.22, 0.3);
      v[3] = 0.28 + Math.max(0, rip) * 4 + 0.18 * s4;
    } else if (st === 1) { // reasoning: particles flowing along a trefoil knot
      const u = (s1 + t * 0.04) * TAU, r = Math.cos(3 * u) + 2;
      const j = PERM2[i] * 3, tube = 0.09 * Math.sqrt(s2);
      v[0] = r * Math.cos(2 * u) * 0.29 + SPH[j] * tube;
      v[1] = r * Math.sin(2 * u) * 0.29 + SPH[j + 1] * tube;
      v[2] = -Math.sin(3 * u) * 0.29 + SPH[j + 2] * tube;
      rot(v, t * 0.34, 0.55 + Math.sin(t * 0.3) * 0.35);
      v[3] = 0.26 + 0.4 * s4;
    } else if (st === 2) { // searching: tilted sonar with a rotating beam
      const rho = s1 < 0.7 ? ((Math.floor(s2 * 5) + 1) / 5) * 0.92 + (s3 - 0.5) * 0.016 : Math.sqrt(s2) * 0.92;
      const ang = s4 * TAU, dd = (((t * 2.2 - ang) % TAU) + TAU) % TAU, beam = Math.exp(-dd * 1.6);
      v[0] = rho * Math.cos(ang); v[2] = rho * Math.sin(ang); v[1] = beam * 0.06 * (1 - rho * 0.5) + (s3 - 0.5) * 0.012;
      rot(v, 0.14 * t, -0.8);
      v[3] = (s1 < 0.7 ? 0.2 : 0.08) + 1.25 * beam;
    } else { // done: ring + check mark drawn in
      const b = 1 + 0.015 * Math.sin(t * 1.6);
      if (s1 < 0.5) {
        const rho = 0.86 + (s2 - 0.5) * 0.045, ang = s3 * TAU + Math.PI / 2;
        v[0] = Math.cos(ang) * rho * b; v[1] = Math.sin(ang) * rho * b; v[2] = (s4 - 0.5) * 0.06; v[3] = 0.3;
      } else {
        const d = s2 * LT; let x, y, nx, ny;
        if (d < L1) { const k = d / L1; x = CA[0] + (CB[0] - CA[0]) * k; y = CA[1] + (CB[1] - CA[1]) * k; nx = 0.69; ny = 0.72; }
        else { const k = (d - L1) / L2; x = CB[0] + (CC[0] - CB[0]) * k; y = CB[1] + (CC[1] - CB[1]) * k; nx = -0.72; ny = 0.69; }
        const off = (s3 - 0.5) * 0.07;
        v[0] = (x + nx * off) * b; v[1] = (y + ny * off) * b; v[2] = (s4 - 0.5) * 0.07; v[3] = 0.42;
      }
      rot(v, Math.sin(t * 0.6) * 0.2, 0);
    }
  }
  const delayOf = (st, i) => {
    const s1 = S[i * 4], s2 = S[i * 4 + 1], s3 = S[i * 4 + 2];
    if (st === 3) return s1 < 0.5 ? s3 * 0.35 : 0.3 + s2 * 0.4; // ring first, then the check draws in
    return s1 * 0.22;
  };

  // ---- state
  let time = 0, cur = 0, prev = 0, T0 = -1e9, playing = false, raf = 0, last = 0, visible = true, destroyed = false;
  let W = 0, H = 0;
  const MAXD = 0.75;

  function resize() {
    const dpr = Math.min(window.devicePixelRatio || 1, o.maxDpr);
    const w = Math.max(1, Math.round(canvas.clientWidth * dpr)), h = Math.max(1, Math.round(canvas.clientHeight * dpr));
    if (w !== W || h !== H) { W = canvas.width = w; H = canvas.height = h; gl.viewport(0, 0, W, H); }
  }

  function compute(t) {
    voice = voiceOverride ?? 0.5 + 0.5 * Math.sin(t * 1.9) * Math.sin(t * 3.1 + 1.2);
    const inT = t - T0 < o.transition + MAXD, c = COLORS[cur];
    for (let i = 0; i < N; i++) {
      shape(cur, i, t, tmp);
      const spark = S[i * 4 + 3] > 0.965 ? 0.25 : 0, br = tmp[3] * 0.8;
      let r = (c[0] + spark) * br, g = (c[1] + spark) * br, b = (c[2] + spark) * br;
      let x = tmp[0], y = tmp[1], z = tmp[2];
      const k3 = i * 3;
      if (inT) {
        const l = clamp((t - T0 - delayOf(cur, i)) / o.transition), e = ease(l);
        const burst = Math.sin(Math.PI * l) * 0.24 * (0.4 + S[i * 4 + 1]), j = PERM2[(i + 17) % N] * 3;
        x = lerp(fromP[k3], x, e) + SPH[j] * burst;
        y = lerp(fromP[k3 + 1], y, e) + SPH[j + 1] * burst;
        z = lerp(fromP[k3 + 2], z, e) + SPH[j + 2] * burst;
        r = lerp(fromC[k3], r, e); g = lerp(fromC[k3 + 1], g, e); b = lerp(fromC[k3 + 2], b, e);
      }
      pos[k3] = x; pos[k3 + 1] = y; pos[k3 + 2] = z; col[k3] = r; col[k3 + 1] = g; col[k3 + 2] = b;
    }
  }

  function draw() {
    resize();
    const R = (Math.min(W, H) / 2) * o.scale;
    gl.clear(gl.COLOR_BUFFER_BIT);
    gl.bindBuffer(gl.ARRAY_BUFFER, bPos); gl.bufferData(gl.ARRAY_BUFFER, pos, gl.DYNAMIC_DRAW);
    gl.bindBuffer(gl.ARRAY_BUFFER, bCol); gl.bufferData(gl.ARRAY_BUFFER, col, gl.DYNAMIC_DRAW);
    gl.uniform2f(U.uRes, W, H); gl.uniform2f(U.uC, W / 2, H / 2); gl.uniform1f(U.uR, R);
    if (o.glow > 0) {
      gl.uniform1f(U.uPt, Math.max(6, R * o.pointSize * 5)); gl.uniform1f(U.uGain, o.glow);
      gl.drawArrays(gl.POINTS, 0, N);
    }
    gl.uniform1f(U.uPt, Math.max(1.6, R * o.pointSize)); gl.uniform1f(U.uGain, 1);
    gl.drawArrays(gl.POINTS, 0, N);
  }

  function frame(now) {
    if (destroyed) return;
    const dt = last ? Math.min(0.1, (now - last) / 1000) : 0; last = now;
    if (playing && visible) { time += dt * o.speed; compute(time); draw(); }
    raf = requestAnimationFrame(frame);
  }

  const toIndex = (s) => (typeof s === "number" ? ((s % 4) + 4) % 4 : ORB_STATES.indexOf(s));

  const api = {
    /** Switch state by name ("listening" | "reasoning" | "searching" | "done") or index 0-3. */
    setState(s, { instant = false } = {}) {
      const i = toIndex(s); if (i < 0) throw new Error(`AIStatusOrb: unknown state "${s}"`);
      if (i === cur && !instant) return api;
      fromP.set(pos); fromC.set(col);
      prev = cur; cur = i; T0 = instant ? -1e9 : time;
      o.onStateChange?.(ORB_STATES[i], i);
      return api;
    },
    getState: () => ORB_STATES[cur],
    /** Current accent color as [r,g,b] 0-255, blended during transitions. Handy for tinting your UI. */
    getColor() {
      const k = ease(clamp((time - T0) / o.transition)), a = COLORS[prev], b = COLORS[cur];
      return [0, 1, 2].map((n) => Math.round(lerp(a[n], b[n], k) * 255));
    },
    /** Feed a live mic level (0..1) to the listening state. Pass null to go back to the idle wobble. */
    setVoiceLevel(v) { voiceOverride = v == null ? null : clamp(v); return api; },
    setColors(hexes) { COLORS = hexes.map(hexToRgb); return api; },
    /** Render one frame at an exact time in seconds (for screenshots or video export). */
    renderAt(t) { time = t; compute(t); draw(); return api; },
    play() { playing = true; last = 0; return api; },
    pause() { playing = false; return api; },
    resize() { W = H = 0; resize(); return api; },
    get time() { return time; },
    destroy() {
      destroyed = true; cancelAnimationFrame(raf); io?.disconnect();
      document.removeEventListener("visibilitychange", onVis);
      gl.getExtension("WEBGL_lose_context")?.loseContext();
    },
  };

  // pause when off screen or tab hidden
  const onVis = () => { visible = !document.hidden; last = 0; };
  document.addEventListener("visibilitychange", onVis);
  const io = typeof IntersectionObserver === "function"
    ? new IntersectionObserver(([e]) => { visible = e.isIntersecting && !document.hidden; last = 0; })
    : null;
  io?.observe(canvas);

  compute(0);
  if (o.autoplay) api.play();
  raf = requestAnimationFrame(frame);
  return api;
}
