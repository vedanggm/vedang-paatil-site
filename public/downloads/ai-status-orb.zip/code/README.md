# AI Status Orb

A particle orb that shows what your AI is doing: listening, reasoning, searching, done.
One WebGL draw call, no dependencies.

## Try it
Open `index.html` in your browser. Click a state or press 1–4.

## Vanilla JS
```html
<canvas id="orb" style="width:320px;height:320px"></canvas>
<script type="module">
  import { createAIStatusOrb } from "./ai-status-orb.js";
  const orb = createAIStatusOrb(document.getElementById("orb"));

  orb.setState("listening");   // user is talking
  orb.setState("reasoning");   // model is thinking
  orb.setState("searching");   // tool call / retrieval
  orb.setState("done");        // answer ready
</script>
```

## React / Next.js
Copy `ai-status-orb.js`, `ai-status-orb.d.ts` and `AIStatusOrb.tsx` into the same folder.
```tsx
import AIStatusOrb from "./AIStatusOrb";

<div style={{ width: 320, height: 320 }}>
  <AIStatusOrb state={status} />
</div>
```

## Options
| option | default | what it does |
|---|---|---|
| particles | 16000 | particle count (8000 for low-end phones) |
| colors | rose, periwinkle, amber, mint | 4 hex colors, one per state |
| scale | 0.8 | orb size relative to the canvas |
| pointSize | 0.011 | particle size |
| glow | 0.018 | soft glow pass, 0 turns it off |
| speed | 1 | global animation speed |
| transition | 1.15 | morph duration in seconds |

## Voice apps
Feed a live mic level (0 to 1) to the listening state:
```js
orb.setVoiceLevel(level); // null goes back to the idle wobble
```

## Tint your UI with the orb
`orb.getColor()` returns the current `[r, g, b]`, blended during transitions.

Made by Vedang Paatil. More builds: vedangpaatil.com/library
